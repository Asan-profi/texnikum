# Xo‘jayli tumani 1-son texnikumi sayti

To‘rtta tildagi sayt va yangiliklarni boshqarish paneli. Tayyor hosting paketi, 1.0.

## Avval o‘qing

1. `docs/Hosting_yoriqnomasi.docx` — hostingga joylashtirish, baza va birinchi admin hisobini sozlash.
2. `docs/Buyurtmachi_yoriqnomasi.docx` — yangilik qo‘shish, tahrirlash va o‘chirish bo‘yicha rasmli qo‘llanma.

Bu oddiy statik HTML paket emas: PHP va MySQL/MariaDB kerak. Composer, npm yoki Node.js serverda kerak emas.

## Papkalar

- `public_html/` — domenning ochiq sayt papkasiga joylashtiriladigan fayllar.
- `texnikum_private/` — ochiq papkaning yonida, undan tashqarida turadigan PHP kodi va sozlamalar.
- `docs/` — mutaxassis va buyurtmachi yo‘riqnomalari; ochiq sayt papkasiga yuklamang.

Misol: `/home/HISOB/public_html` va `/home/HISOB/texnikum_private`. Qo‘shimcha domen ildizi boshqa ochiq sayt papkasi ichida bo‘lsa, hosting yordamida uni alohida ildiz papkaga moslang, shunda xususiy papka hamma domenlarning ochiq papkalaridan tashqarida qoladi.

## Qisqa ishga tushirish tartibi

1. Eski sayt va bazani zaxiralang. HTTPS sertifikatini tekshiring.
2. PHP 8.2+ (8.3 yoki 8.4 tavsiya), PDO MySQL, mbstring, GD, fileinfo va ctype ni yoqing. GD JPEG, PNG va WebP o‘qiy olsin. Apache/LiteSpeed `.htaccess` qoidalarini qabul qilishi kerak.
3. Domen papkasiga `public_html` ichidagilarni, uning yoniga `texnikum_private`ni joylashtiring. Yashirin `.htaccess` fayllarini ham ko‘chiring.
4. Yangi bo‘sh MySQL/MariaDB baza va unga foydalanuvchi yarating. `config.example.php`ni `config.php`ga nusxalang; domen, baza va kamida 32 belgili tasodifiy `setup_key`ni yozing.
5. `uploads` va xususiy `runtime` papkalari PHP uchun yoziladigan bo‘lsin. Yuklash uchun kamida 5M, so‘rov uchun 16M, xotira uchun 192M tavsiya qilinadi.
6. `https://DOMEN/install.php`ni ochib, tekshiruvlarni bajaring va admin login/parolini o‘zingiz yarating. `schema.sql`ni oldindan import qilmang.
7. O‘rnatilgach, `install.php`ni o‘chiring va `setup_key`ni bo‘shating.
8. `https://DOMEN/admin/index.php`dan kiring. Bu paketda tayyor umumiy admin paroli yo‘q.

## Tayyor imkoniyatlar

- O‘zbek, qoraqalpoq, rus va ingliz tilidagi interfeys, 6 mavjud yangilikning barcha tarjimalari, 9 ta ta’lim yo‘nalishi.
- Moslashuvchan sahifalar, mobil menyu, tilni eslab qolish, maqola ichida tilni almashtirish.
- Admin login/paroli, yangilik qo‘shish/tahrirlash/o‘chirish, qoralama, rasm yuklash, qidirish va sahifalash.
- Hamma tashrifchilar e’lon qilingan yangiliklarni hisob yaratmasdan o‘qiydi.
- Rasmni tekshirish va qayta kodlash, parolni xeshlash, CSRF himoyasi, tayyorlangan SQL so‘rovlari, kirish urinishlarini cheklash.
- Matn xavfsiz oddiy matn sifatida chiqariladi; HTML kod ishga tushirilmaydi.
- Sahifa metama’lumotlari, canonical va til havolalari, dinamik `sitemap.php`, siqish/kesh sozlamalari.

Keyingi yangiliklar avtomatik tarjima qilinmaydi: admin to‘rtta tilni alohida to‘ldiradi. Boshqaruv paneli o‘zbek tilida. E’lon qilishda to‘rtta til majburiy; qoralama uchun o‘zbekcha sarlavha va matn yetarli.

## Kontent va zaxira

Buyurtmachi ishga tushirishdan oldin tarjimalar, atoqli otlar, telefon, manzil va havolalarni tekshirsin. Dastlabki arxivdagi email ishonchli formatda emasligi sababli bo‘sh qoldirilgan; tasdiqlangan emailni `config.php`ga qo‘shing.

Bosh sahifa matnlari `texnikum_private/content.json`da, dastlabki yangiliklar `seed.json`da. O‘rnatilgandan keyingi yangiliklar bazada boshqariladi; `seed.json`ni o‘zgartirish mavjud yangiliklarni yangilamaydi.

Sayt ishlay boshlagach, yangiliklarni saqlash uchun baza eksporti va `public_html/uploads` nusxasi kerak. `config.php` va xususiy sozlamalarni ham xavfsiz zaxiralang. Dastlabki ZIP keyingi yangiliklarning zaxirasi emas.

## Sinov va hostingdagi yakuniy tekshiruv

Mahalliy PHP 8.3/MariaDB 10.11 muhitida 43 ta funksional va Chromium brauzerida 34 ta tekshiruv o‘tdi. To‘rtta til 320, 390, 768 va 1280 px kengliklarda tekshirildi. Rasm fayllari alohida ochib tekshirildi.

19 ta rasmning jami hajmi 26 331 418 baytdan 2 229 362 baytga kamaytirildi, taxminan 91,5%. Bu PageSpeed natijasi yoki yuklanish tezligi kafolati emas.

Haqiqiy hostingga hali o‘rnatilmagan. Uning PHP, HTTPS, fayl ruxsatlari va Apache/LiteSpeed `.htaccess` qoidalari hostingda tekshirilishi kerak. Nginx ishlatilsa, shu himoya va kesh qoidalarini server sozlamasiga mutaxassis moslashtiradi. To‘liq qo‘llanma `docs/Hosting_yoriqnomasi.docx`da.
